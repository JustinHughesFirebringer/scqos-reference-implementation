# SCQOS findings: reproduction bundle

Every finding below comes from one script. It clones the public repository at a pinned commit, runs the tests, and writes every input, request, response and output to `results/`.

```bash
bash reproduce.sh        # needs git, curl, python3 >= 3.10; ~2 minutes; no paid quantum calls
```

**Commit under test:** `23280c78075a49eee98c1548047f013ffd471444` (2026-10-22, "research: publish SC 1080° evidence and real QPU execution receipts"). This was also `main` when the bundle was run. `results/` holds the run from 2026-10-23 19:18–19:23 UTC; `results/environment.txt` and `results/inputs.sha256` pin the environment and the exact bytes of every source file read.

## Scope

Tested:
- The October 22 evidence release (`research/sc-1080-evidence-20261022/`).
- The decision function it calls, `integration.universal_gateway.govern_transition`.
- The Linux launcher's use of that function (`kernel_integration/scqos_kernel_exec.py`).
- The separate ProofGate public-challenge engine.

Not tested:
- The BPF-LSM kernel hook running live. That needs a bpf-LSM kernel. I take its documented behaviour (no grant → `EACCES`) as given. The question here is what decides whether a grant is issued.
- A Kubernetes admission gate. None exists in this repository; a link would allow the same tests.
- The IBM/AWS job records themselves. Only the owning account can retrieve them.

## Answers to the eight questions, mapped to files

| # | Question | Where the evidence is |
|---|---|---|
| 1 | Commit, files, environment, timestamps, logs | `environment.txt`, `inputs.sha256`, `run.log` (start/finish UTC), `SHA256SUMS` |
| 2 | Scope / where continuity breaks | `05_qpu/result.json`: the manifest was generated 08:02:50 UTC and records hardware as "not submitted". The IBM job (08:09) and Braket task (08:16) appear nowhere in the chain. `ibm_real_qpu.py` never calls SCQOS. |
| 3 | Full requests, responses, expected policy; action vs authorization | `03_gateway/*.request.json` / `*.response.json` and `summary.json`. Each case names the repository rule it should have triggered. Authority is a caller-written string in both engines; see `04_proofgate/result.json`. |
| 4 | Forgery artifacts, modifications, script, output | `02_forgery/original_manifest.json`, `forged_manifest.json`, `forged_manifest.diff`, `result.json`; script `tests/forge_manifest.py` |
| 5 | Enforced boundary vs generic interface | `03_gateway/06_kernel_launcher_destructive_exec.*` is a request shaped exactly as `scqos_kernel_exec.py` builds it (lines 163–184). It returns `PERMIT`, `execution_authorized: true`. The launcher's only conditions for installing the grant are those two values plus the executable being unchanged (lines 198–205). The documented kernel denial test enrolls a child *without* a grant. It shows the hook enforces a decision; it does not test whether the decision refuses anything. |
| 6 | Source-value mismatch and the failing condition | `02_forgery/result.json`: the source file says 7.94167639, the forged manifest says 9.9999, and `verify()` returns `True`. No condition in `verify_release.py` compares a recorded value to the source file. Lines 12–15 and 21 check only file hashes and hash strings. Lines 23–24 check that gate proofs exist and are non-empty. |
| 7 | What was submitted, authorized, executed | Submitted: the `*.request.json` files. Authorized: the `*.response.json` files. Executed: nothing; the tests stop at the decision. On the Linux path, the decision is what produces the exec grant. |
| 8 | Local receipt vs externally verifiable record | `05_qpu/result.json`: both hardware receipts are written by the release's own scripts and carry a self-hash, not a provider signature. The gateway's gate proofs use an HMAC key generated on the host (`universal_gateway.py` 36–50), so no third party can check them. |

## What would overturn each finding

- **Forgery:** `verify_release.verify()` rejects `results/02_forgery/forged_manifest.json`.
- **Gateway:** `govern_transition` returns `REJECT` or `HOLD` for cases 02–06 at this commit.
- **Continuity:** the IBM job ID or Braket task ARN appears inside a hash-chained record generated before or with the jobs.
- **External verifiability:** a published public key and signatures (or a transparency-log entry) that let a third party check a receipt without the author's secret or cloud account.

Also included: `00` DESI files are byte-identical to upstream, and `06_chi2` is an independent recomputation (χ² = 28.97 for 13 points, ~2.7σ). Both confirm the release's data and arithmetic.
