#!/usr/bin/env bash
# One-command reproduction of the findings on scqos-reference-implementation.
# Needs: git, curl, python3 (>=3.10). Runs offline after the clone and pip install.
# Makes no paid quantum calls, writes nothing outside ./work and ./results.
set -euo pipefail

REPO=https://github.com/KnowledgeeKZA3224/scqos-reference-implementation.git
COMMIT=23280c78075a49eee98c1548047f013ffd471444
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$HERE/work"; RES="$HERE/results"; T="$HERE/tests"
rm -rf "$WORK" "$RES"; mkdir -p "$WORK" "$RES"
exec > >(tee "$RES/run.log") 2>&1

echo "== started_utc: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
git clone -q "$REPO" "$WORK/repo"
git -C "$WORK/repo" checkout -q "$COMMIT"
REPO_DIR="$WORK/repo"; EV="$REPO_DIR/research/sc-1080-evidence-20261022"
export SCQOS_COMMIT="$(git -C "$REPO_DIR" rev-parse HEAD)"

python3 -m venv "$WORK/venv"; PY="$WORK/venv/bin/python"
"$PY" -m pip install -q --upgrade pip
"$PY" -m pip install -q numpy==2.5.3 scipy==1.18.1 fastapi==0.162.0 pydantic==2.13.5 rfc8785==0.1.4

{ echo "commit_under_test: $SCQOS_COMMIT"
  echo "commit_date: $(git -C "$REPO_DIR" log -1 --format=%cI)"
  echo "remote_main_now: $(git ls-remote "$REPO" refs/heads/main | cut -f1)"
  echo "os: $(uname -srm)"; echo "python: $("$PY" --version)"
  "$PY" -m pip freeze | grep -iE '^(numpy|scipy|fastapi|pydantic|pydantic.core|rfc8785|starlette)=='
} | tee "$RES/environment.txt"

( cd "$REPO_DIR" && sha256sum \
    research/sc-1080-evidence-20261022/{verify_release.py,sc_totality_engine.py,planck_desi_comparison.py,ibm_real_qpu.py,braket_real_qpu.py} \
    research/sc-1080-evidence-20261022/data/* research/sc-1080-evidence-20261022/output/* \
    integration/universal_gateway.py scqos_supreme_stack.py kernel_integration/scqos_kernel_exec.py \
    challenge/public_execution_challenge/runtime.py ) > "$RES/inputs.sha256"

echo; echo "== 0. DESI files vs upstream Cobaya bao_data"
mkdir -p "$WORK/upstream"
for f in mean cov; do
  curl -sSf -o "$WORK/upstream/desi_dr2_$f.txt" \
    "https://raw.githubusercontent.com/CobayaSampler/bao_data/master/desi_bao_dr2/desi_gaussian_bao_ALL_GCcomb_$f.txt"
  cmp "$WORK/upstream/desi_dr2_$f.txt" "$EV/data/desi_dr2_$f.txt" && echo "desi_dr2_$f.txt identical to upstream"
done

echo; echo "== 1. Published verifier, unmodified, on the published manifest"
( cd "$WORK" && "$PY" -I "$EV/verify_release.py" ) | tee "$RES/01_published_verifier.txt"

echo; echo "== 2. Forged manifest vs the same verifier (Q4, Q6)"
( cd "$WORK" && "$PY" -I "$T/forge_manifest.py" "$EV" "$RES/02_forgery" )

echo; echo "== 3. Universal gateway decisions (Q3, Q5, Q7)"
mkdir -p "$WORK/gw_cwd"   # gate audit files land here, not in the repo
( cd "$WORK/gw_cwd" && "$PY" -I "$T/gateway_probe.py" "$REPO_DIR" "$EV" "$RES/03_gateway" )

echo; echo "== 4. ProofGate public-challenge engine (Q3)"
( cd "$WORK/gw_cwd" && "$PY" -I "$T/proofgate_probe.py" "$REPO_DIR" "$RES/04_proofgate" )

echo; echo "== 5. QPU runs vs the hash chain (Q2, Q8)"
"$PY" -I "$T/qpu_continuity.py" "$EV" "$RES/05_qpu" > /dev/null && cat "$RES/05_qpu/result.json"

echo; echo "== 6. Independent chi-square"
"$PY" -I "$T/chi2_check.py" "$WORK/upstream" "$RES/06_chi2"

( cd "$RES" && find . -type f ! -name SHA256SUMS ! -name run.log | sort | xargs sha256sum > SHA256SUMS )
echo; echo "== finished_utc: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
