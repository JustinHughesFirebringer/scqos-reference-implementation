"""Q4 / Q6 - Can a modified 1080-release manifest pass the release's own verifier?

Usage: python forge_manifest.py <evidence_dir> <out_dir>

The repository is not modified. The forged manifest is written only to <out_dir>
and passed to the unmodified verify_release.verify() function.
"""
import copy, difflib, hashlib, importlib.util, json, pathlib, sys

E, OUT = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)

spec = importlib.util.spec_from_file_location("verify_release", E / "verify_release.py")
vr = importlib.util.module_from_spec(spec); spec.loader.exec_module(vr)

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(obj): return json.dumps(obj, indent=2, sort_keys=True) + "\n"
def run_verify(label, manifest):
    try:
        return {"input": label, "verify_release.verify": vr.verify(manifest, root=E)}
    except AssertionError as e:
        return {"input": label, "verify_release.verify": "AssertionError", "message": str(e)}

src_mean = E / "data/desi_dr2_mean.txt"
src_cov = E / "data/desi_dr2_cov.txt"
manifest_path = E / "output/sc_totality_manifest.json"
original = json.loads(manifest_path.read_bytes())

# --- control: the release's own naive tamper test (edit without recomputing hashes)
naive = copy.deepcopy(original)
naive["measurements"][0]["measurement"] += 1

# --- forgery: falsify a value, replace all gate proofs, recompute the unkeyed chain
forged = copy.deepcopy(original)
forged["measurements"][0]["measurement"] = 9.9999          # source file says 7.94167639
for row in forged["measurements"]:
    row["scqos"]["gate_proofs"] = {f"fake_{i}": "fake" for i in range(8)}
    row["scqos"]["final_proof"] = "fake"
    row["scqos"]["receipt_hash"] = "fake"
prev = "0" * 64
for row in forged["measurements"]:
    row["parent_hash"] = prev
    row["chain_hash"] = hashlib.sha256(
        vr.canonical({k: v for k, v in row.items() if k != "chain_hash"})).hexdigest()
    prev = row["chain_hash"]
forged["final_chain_hash"] = prev

(OUT / "original_manifest.json").write_bytes(manifest_path.read_bytes())
(OUT / "forged_manifest.json").write_text(dump(forged))
(OUT / "forged_manifest.diff").write_text("".join(difflib.unified_diff(
    dump(original).splitlines(True), dump(forged).splitlines(True),
    "original_manifest.json", "forged_manifest.json", n=1)))

first_row = next(l for l in src_mean.read_text().splitlines() if l.strip() and not l.startswith("#"))
result = {
    "source_files_untouched": {
        "desi_dr2_mean.txt_sha256": sha(src_mean), "desi_dr2_cov.txt_sha256": sha(src_cov),
        "pinned_in_verify_release": vr.PIN,
        "match": sha(src_mean) == vr.PIN["mean"] and sha(src_cov) == vr.PIN["covariance"]},
    "measurement_0": {"in_source_file": first_row,
                      "in_original_manifest": original["measurements"][0]["measurement"],
                      "in_forged_manifest": forged["measurements"][0]["measurement"]},
    "verify_original": run_verify("original_manifest.json", original),
    "verify_naive_tamper": run_verify("naive edit, hashes not recomputed", naive),
    "verify_forged": run_verify("forged_manifest.json", forged),
    "why": ("verify_release.py checks the on-disk source file hashes and that each row "
            "carries the pinned hash string, but no line parses the source file and compares "
            "row['measurement'] to it. Gate proofs are checked only for count >= 8 and "
            "non-emptiness. The chain is plain SHA-256 with no key or external anchor, so "
            "anyone can recompute it."),
}
(OUT / "result.json").write_text(dump(result))
print(dump(result))
