"""Q3 (authorization) - the separate ProofGate public-challenge engine.

Usage: python proofgate_probe.py <repo_root> <out_dir>

This engine (challenge/public_execution_challenge/runtime.py) has real content checks
and KMS signing in production. It is NOT the engine the 1080 release or the Linux
launcher calls. Run in SCQOS_TEST_MODE=1 so nothing is signed or stored remotely.
"""
import json, os, pathlib, sys, time

os.environ["SCQOS_TEST_MODE"] = "1"
ROOT, OUT = (pathlib.Path(a).resolve() for a in sys.argv[1:3])
OUT.mkdir(parents=True, exist_ok=True)
sys.path[:0] = [str(ROOT), str(ROOT / "challenge/public_execution_challenge")]
import runtime as rt

matrix = rt.run_matrix()          # the author's own six frozen cases

# A request in which every field is internally consistent, so it satisfies every
# check in _contract_decision (runtime.py lines 79-102), but the action is destructive
# and the principal is whoever typed the request. 'challenge:execute' is a string the
# caller supplies; nothing binds it to an authenticated identity.
now = time.time()
attack = {
    "tenant_id": "public-challenge", "external_system": "ai_tool_call",
    "subject": "production/database/customers",
    "authority": {"principal_id": "anonymous-internet-user", "scope": "challenge:execute"},
    "intent": {"action": "drop_database", "target": "customers-db", "expected_effect": "all_rows_deleted"},
    "evidence": {"observed_at": now, "source": "self-asserted", "reference_id": "none-1", "target": "customers-db"},
    "current_state": {"rows": 1_000_000},
    "proposed_transition": {"action": "drop_database", "target": "customers-db",
                            "effect": "all_rows_deleted", "reference_id": "none-1"},
    "expected_consequence": {"effect": "all_rows_deleted"},
}
receipt = rt.evaluate(attack, now)

out = {"own_matrix": matrix,
       "self_consistent_destructive_request": attack,
       "decision": receipt["decision"], "release_authorized": receipt["release_authorized"],
       "receipt": receipt}
(OUT / "result.json").write_text(json.dumps(out, indent=2, default=str) + "\n")
print(f"own matrix: {matrix['passed']}/{matrix['total']} as designed")
print(f"self-consistent destructive request from anonymous principal: {receipt['decision']}")
