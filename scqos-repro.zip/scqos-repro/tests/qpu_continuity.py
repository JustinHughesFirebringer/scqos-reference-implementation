"""Q2 / Q8 - Are the QPU executions inside the release's hash chain?

Usage: python qpu_continuity.py <evidence_dir> <out_dir>
"""
import json, pathlib, sys

E, OUT = (pathlib.Path(a) for a in sys.argv[1:3])
OUT.mkdir(parents=True, exist_ok=True)
raw = (E / "output/sc_totality_manifest.json").read_text()
m = json.loads(raw)
ibm = json.loads((E / "output/ibm_quantum_hardware_job.json").read_text())
aws = json.loads((E / "output/aws_braket_hardware_job.json").read_text())

result = {
    "manifest_generated_utc": m["generated_utc"],
    "manifest_quantum_section": m["quantum"],
    "ibm": {"submitted_utc": ibm["submitted_utc"], "job_id": ibm["job_id"],
            "job_id_in_manifest": ibm["job_id"] in raw,
            "ibm_real_qpu.py_calls_govern_transition": "govern_transition" in (E / "ibm_real_qpu.py").read_text()},
    "aws": {"created_utc": aws["created_utc"], "task_arn": aws["qpu_task_arn"],
            "task_arn_in_manifest": aws["qpu_task_arn"] in raw,
            "scqos_pre_execution_receipt_in_manifest": aws["scqos_pre_execution_receipt"] in raw},
    "receipt_provenance": ("Both hardware JSON files are written by the author's own scripts "
                           "(ibm_real_qpu.py lines 23-39, braket_real_qpu.py lines 29-49). result_sha256 "
                           "is a self-hash. Neither carries a provider signature; the job ID and task ARN "
                           "are retrievable only by the owning IBM / AWS account."),
    "measurement_basis": ("Both circuits measure only the computational (ZZ) basis. A classical 50/50 "
                          "mixture of |00> and |11> gives the same correlation, so these runs do not "
                          "evidence entanglement. An X-basis or CHSH measurement would."),
    "ibm_counts": ibm["counts"], "aws_counts": aws["counts"],
}
(OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
