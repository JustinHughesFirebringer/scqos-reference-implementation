"""Independent recomputation of the Planck-2018 vs DESI DR2 BAO chi-square.

Usage: python chi2_check.py <dir containing desi_dr2_mean.txt and desi_dr2_cov.txt> <out_dir>
Written from scratch; shares no code with planck_desi_comparison.py.
"""
import json, pathlib, sys
import numpy as np
from scipy.integrate import quad
from scipy.stats import chi2, norm

D, OUT = (pathlib.Path(a) for a in sys.argv[1:3])
OUT.mkdir(parents=True, exist_ok=True)
rows = [l.split() for l in (D / "desi_dr2_mean.txt").read_text().splitlines() if l.strip() and not l.startswith("#")]
z = np.array([float(r[0]) for r in rows]); y = np.array([float(r[1]) for r in rows]); k = [r[2] for r in rows]
C = np.loadtxt(D / "desi_dr2_cov.txt"); c = 299792.458

def model(H0, Om, rd, Or=0.0):
    E = lambda x: np.sqrt(Om * (1 + x) ** 3 + Or * (1 + x) ** 4 + 1 - Om - Or)
    out = []
    for zi, ki in zip(z, k):
        DH = c / (H0 * E(zi)); DM = c / H0 * quad(lambda x: 1 / E(x), 0, zi)[0]
        out.append({"DM_over_rs": DM, "DH_over_rs": DH, "DV_over_rs": (zi * DM * DM * DH) ** (1 / 3)}[ki] / rd)
    return np.array(out)

def chi(m):
    d = y - m; return float(d @ np.linalg.solve(C, d))

Or = 2.47e-5 * (1 + 0.2271 * 3.046) / 0.674 ** 2
res = {}
for label, m in [("as_published_rounded_no_radiation", model(67.4, 0.315, 147.09)),
                 ("plus_radiation", model(67.4, 0.315, 147.09, Or)),
                 ("planck_exact_bestfit_plus_radiation", model(67.36, 0.3153, 147.09, Or))]:
    x = chi(m); p = chi2.sf(x, 13)
    res[label] = {"chi2": round(x, 3), "p": round(float(p), 5), "approx_sigma": round(float(norm.isf(p / 2)), 2)}
    print(f"{label:38s} chi2={x:6.2f} p={p:.4f} ~{norm.isf(p/2):.1f} sigma")
res["context"] = "DESI DR2 (arXiv:2503.14738) itself reports a 2.3 sigma BAO-CMB tension in LCDM."
(OUT / "result.json").write_text(json.dumps(res, indent=2) + "\n")
