"""Q3 / Q5 / Q7 - What does integration.universal_gateway.govern_transition refuse?

Usage: python gateway_probe.py <repo_root> <evidence_dir> <out_dir>

This is the decision function called by the 1080 release (sc_totality_engine.gate,
braket_real_qpu.py) and by the Linux launcher kernel_integration/scqos_kernel_exec.py,
which installs a BPF-LSM exec grant iff decision == PERMIT and execution_authorized.
Nothing is executed here; each request and full response is written to <out_dir>.
"""
import copy, hashlib, json, os, pathlib, platform, sys

ROOT, E, OUT = (pathlib.Path(a).resolve() for a in sys.argv[1:4])
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT))
from integration.universal_gateway import TransitionRequest, govern_transition
import scqos_supreme_stack as sc

row = json.loads((E / "output/sc_totality_manifest.json").read_bytes())["measurements"][0]

# Baseline: byte-for-byte the request sc_totality_engine.gate() builds for measurement 0.
BASE = dict(
    tenant_id="supreme-computation", external_system="DESI-DR2", subject=row["id"],
    authority={"principal_id": "SC-evidence-runtime", "scope": "scientific-evidence-validation"},
    intent="verify published measurements and preserve original statistical reference",
    evidence={"url": row["source_url"], "sha256": row["source_hash"],
              "covariance_sha256": row["covariance_hash"], "sigma": row["sigma"]},
    current_state={"redshift": row["redshift"], "quantity": row["quantity"], "value": row["measurement"]},
    proposed_transition={"operation": "ingest_verified_measurement", "id": row["id"]},
    expected_consequence={"auditable": True, "no_unsupported_causal_inference": True},
    metadata={"kind": "published_observation", "scope": "integrity_not_physics_proof"},
)

def variant(**over):
    v = copy.deepcopy(BASE); v.update(over); return v

# Request shaped exactly as kernel_integration/scqos_kernel_exec.py builds it (lines 163-184),
# for a destructive command, with an unauthenticated principal and a forbidden objective.
target = pathlib.Path("/bin/rm") if pathlib.Path("/bin/rm").exists() else pathlib.Path(sys.executable)
st = target.stat()
binding = {"pid": 424242, "path": str(target),
           "argv": [str(target), "-rf", "--no-preserve-root", "/var/lib/postgresql"],
           "inode": str(st.st_ino), "size": str(st.st_size),
           "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
           "kernel_release": platform.release(), "active_lsms": "lockdown,capability,bpf"}
kernel_req = variant(
    external_system="linux-kernel-exec", subject="host/db-01",
    authority={"principal_id": "anonymous", "scope": "anything"},
    intent="bypass_gate", evidence={},
    current_state={"kernel_runtime": {"kernel_release": binding["kernel_release"],
                                      "active_lsms": binding["active_lsms"]}},
    proposed_transition={"kernel_exec": binding},
    expected_consequence={"kernel_exec": binding, "data_destroyed": True},
    metadata={})

CASES = [
    ("01_baseline_desi_request", BASE, "PERMIT",
     "Control: identical to the request the 1080 release submits."),
    ("02_fabricated_value_no_evidence",
     variant(intent="fabricate data and hide it", evidence={},
             current_state={"redshift": 0.295, "quantity": "DV_over_rs", "value": -1e9}),
     "HOLD", "README.md line 13: HOLD 'when something is missing, stale or contradictory'. "
             "Evidence is empty and the value contradicts the cited source."),
    ("03_unauthenticated_authority",
     variant(authority={"principal_id": "nobody", "scope": "whatever I want"}),
     "REJECT", "README.md line 13: REJECT 'when a hard rule or authority boundary is crossed'. "
               "Principal and scope are free text supplied by the caller; nothing authenticates them."),
    ("04_forbidden_objective", variant(intent="bypass_gate"),
     "REJECT", "scqos_supreme_stack.py lines 126-135: FORBIDDEN_OBJECTIVES contains 'bypass_gate'. "
               "universal_gateway.py line 324 hard-codes declared_objective='operate_control_surface', "
               "so the caller's intent never reaches the forbidden-objective check."),
    ("05_declared_harm",
     variant(expected_consequence={"auditable": False, "causes_harm": True}),
     "REJECT or HOLD", "The request itself declares a non-auditable, harmful consequence."),
    ("06_kernel_launcher_destructive_exec", kernel_req,
     "REJECT", "kernel_integration/README.md: a grant is installed only if govern_transition returns "
               "PERMIT and execution_authorized=true. Anonymous principal, scope 'anything', "
               "forbidden objective, no evidence, argv = rm -rf on a database directory."),
    ("07_scope_literally_deny",
     variant(authority={"principal_id": "x", "scope": "deny"}),
     "REJECT", "Control: universal_gateway.py lines 239-254, the only content-based refusal path "
               "(scope in {'', 'none', 'unauthorized', 'deny'})."),
]

summary = []
for name, req, expected, policy in CASES:
    resp = govern_transition(TransitionRequest(**req))
    (OUT / f"{name}.request.json").write_text(json.dumps(req, indent=2) + "\n")
    (OUT / f"{name}.response.json").write_text(json.dumps(resp.model_dump(mode="json"), indent=2) + "\n")
    summary.append({"case": name, "expected": expected, "actual": resp.decision,
                    "execution_authorized": resp.execution_authorized, "policy_reference": policy})
    print(f"{resp.decision:7s} exec_authorized={str(resp.execution_authorized):5s}  {name}")

(OUT / "summary.json").write_text(json.dumps({
    "commit_under_test": os.environ.get("SCQOS_COMMIT", "unknown"),
    "function": "integration.universal_gateway.govern_transition",
    "note": ("Each gate in scqos_supreme_stack.GenericSignedGate.gate() (lines 653-657) HMAC-signs a "
             "state (next_state, lines 599-617) and immediately verifies it with the same key in the "
             "same call (check, lines 626-651). Those steps can fail only on malformed/unserialisable "
             "input, not on the meaning of the request. The key is generated locally "
             "(universal_gateway.py lines 36-50), so outsiders cannot check the proofs."),
    "results": summary}, indent=2) + "\n")
